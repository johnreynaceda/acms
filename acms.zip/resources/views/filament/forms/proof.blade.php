<img src="{{ Storage::url($getRecord()->proof_of_payment) }}" class="h-64 w-64" alt="">
