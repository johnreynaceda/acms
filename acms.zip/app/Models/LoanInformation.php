<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanInformation extends Model
{
    protected $guarded = [];
}
