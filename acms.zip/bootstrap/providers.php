<?php

return [
    App\Providers\AppServiceProvider::class,
    RealRashid\SweetAlert\SweetAlertServiceProvider::class,
];
